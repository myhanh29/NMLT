#include<stdio.h>
#include <math.h>

 
void KiemtraSHT()
{
    int Uoc=0;
    int S=1;
    int n;
    printf("Nhap so nguyen duong: ");
    scanf("%d",&n);
    for (int i = 1; i < n; i++)
    {
        if (n%i == 0) 
        {
            Uoc = Uoc+i;
            S=S*i;
        }
    }
    if (Uoc==S)
    {
        printf("%d la so hoan thien", n);
    }
    else
    {
    printf("%d khong la so hoan thien", n );
    }
}
    int main()
    {
        KiemtraSHT();
        return 0;
        
    }
