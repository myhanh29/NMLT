#include<stdio.h>
#include <math.h>

void tinhtongF() 
{
    int n;
    do{
    printf ("Nhap so nguyen duong n (n>1):");
    scanf ("%d",&n);
    if (n<1)
    {
        printf("So phai lon hon 1!");
    }
    }while (n<1);
    int F=1;
    int i,j;
    for (i=0; i<n; i++)
    {
        for (j=0; j<n-1; j++)
        {
            F=(3*i)-(2*j);
            printf("\nGia tri F la: %d",F);
        }
    }
}
int main()
{
    tinhtongF() ;
    return 0;
}
// Thầy ơi bài này em làm ra không đúng kết quả ạ.