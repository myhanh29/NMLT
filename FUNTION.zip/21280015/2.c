#include <stdio.h>
void kiemtradinhdoixung()
{
    long n;
    do {
        printf("Nhap vao so nguyen duong n : ");
        scanf("%ld", &n);
        if (n < 10 || n > 10000000)
        {
            printf("Moi ban nhap lai so n thoa 10 <= n <= 10000000\n"); 
        }
    } while (n < 10 || n > 10000000);
    long X = 0, temp = n;
    while (temp > 0)
    {
        X = X * 10 + (temp % 10);
        temp /= 10;
    }
        
    if (X == n)
    {
        printf("So %ld la so doi xung", n);
    }
    else printf("So %ld khong la so doi xung", n);
}
int main()
    {
        kiemtradinhdoixung();
        return 0;
        
    }
