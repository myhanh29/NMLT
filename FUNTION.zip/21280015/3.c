#include<stdio.h>
#include<math.h>

void kiemtrasohoanhao() 
{
    int n;
    printf("Nhap so nguyen duong: ");
    scanf("%d",&n);
    int Uoc =0;
    for (int i = 1; i <= n; i++)
    {
        if (n%i == 0) 
        {
            Uoc = Uoc +i;
        }
    }
    if (Uoc==n*2)
    {
        printf("%d la so hoan hao", n);
    }
    else
    {
    printf("%d khong la so hoan hao", n );
    }
}
int main()
{
    kiemtrasohoanhao();
    return 0;
}