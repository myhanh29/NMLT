#include<stdio.h>

void demsoam() {

	double k;
	int dem=0;
	printf("Nhap so k = \n");
	scanf("%lf",&k);
	if(k==0) 
	{
		printf("Moi nhap so khac 0");
	} 
	else 
	{
		if(k<0) 
		 dem++;
		while(k!=0) 
		{
			scanf("%lf",&k);
			if(k<0) 
			 dem++;
		}
	}
	printf("So luong so am la: %d",dem);
}
int main()
{
    demsoam();
    return 0;
}