#include<stdio.h>
#include <math.h>

void timuocchung() 
{
    int a,b;
    
    do{
    printf ("Nhap so nguyen duong a: ");
    scanf ("%d",&a);
    if (a<0)
    {
        printf("So phai lon hon 0.");
    }
    }while (a<0);
    
    do{
    printf ("Nhap so nguyen duong b: ");
    scanf ("%d",&b);
    if (b<0)
    {
        printf("So phai lon hon 0.");
    }
    }while (b<0);
    
    int tmp;
    while(b != 0) 
    {
        tmp = a % b;
        a = b;
        b = tmp;
    }
    printf("Uoc chung lon nhat la: %d", a);
}
int main()
{
    timuocchung();
    return 0;
}