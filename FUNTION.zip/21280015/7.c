#include<stdio.h>
#include <math.h>
void timboichung() 
{
    int a,b;
    
    do{
    printf ("Nhap so nguyen duong a: ");
    scanf ("%d",&a);
    if (a<0)
    {
        printf("So phai lon hon 0.");
    }
    }while (a<0);
    
    do{
    printf ("Nhap so nguyen duong b: ");
    scanf ("%d",&b);
    if (b<0)
    {
        printf("So phai lon hon 0.");
    }
    }while (b<0);
    
    int tich=a*b;
    int bcnn;
    for (int i=1; i<=a*b; i++)
    {
        if(i%a==0 && i%b==0)
        {
            bcnn=i;
        }
    }
    printf("Boi chung lon nhat la: %d", bcnn);
}
int main()
{
    timboichung() ;
    return 0;
}