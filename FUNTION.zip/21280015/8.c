#include<stdio.h>

void daohaiso() 
{
    int a,b;
    printf ("Nhap so nguyen duong a: ");
    scanf ("%d",&a);
    printf ("Nhap so nguyen duong b: ");
    scanf ("%d",&b);
    int temp=a;
    a=b;
    b=temp;
    printf ("\nSo a: %d",a);
    printf("\nSo b: %d",b);
}
int main()
{
    daohaiso() ;
    return 0;
}