#include<stdio.h>
#include <math.h>

int main() 
{
    int n;
    printf ("Nhap so nguyen duong n (0<=n<=255):");
    scanf ("%d",&n);
    // Thầy ơi bài này em không biết làm ạ
}
    